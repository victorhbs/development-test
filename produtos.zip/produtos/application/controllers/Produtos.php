<?php
        class Produtos extends CI_Controller{
                
                
                function __construct(){
                        
                        parent::__construct();
                        
                        //Carregar a library form_validation
                        $this->load->library(array('form_validation'));
                          
                        //Carregar o model
                        $this->load->model('Produtos_model','',TRUE);
                          
                        //Carregar o helper url
                        $this->load->helper('url');
                        
                }
                
                function atualizar(){
                        //Recebendo dados do form via post
                        $id = $this->input->post('id');
                        
                        $produtos = array('nomeProduto' => $this->input->post('nomeProduto'),
                                          'preco' => $this->input->post('preco'),
                                          'estoque' => $this->input->post('estoque'),
                                          );
                        
                        $this->Produtos_model->atualizar($id, $produtos);
                        
                        //Retornar ao index
                        $this->index();
                }
        
                function deletar($id){
                        $this->Produtos_model->deletar($id);
                        
                        redirect('produtos/index', 'refresh');
                }
                
                function inserir(){
                        //Recebendo dados do form via post
                        $produtos = array('nomeProduto' => $this->input->post('nomeProduto'),
                                          'preco' => $this->input->post('preco'),
                                          'estoque' => $this->input->post('estoque'),
                                          );
                
                        $this->Produtos_model->inserir($produtos);
                        $this->index();
                }
                
                function prepararInsercao(){
                        
                        //Criando os campos do form
                        $this->form_validation->id = '';
                        $this->form_validation->nomeProduto = '';
                        $this->form_validation->preco = '';
                        $this->form_validation->estoque = '';
                        
                        //Array data que armazena algumas variaveis usadas na view
                        $data = array(
                               'title' => 'Novo',
                               'action' => site_url('produtos/inserir'),
                );
                        
                //carregar view passando os valores do array data
                $this->load->view('produtos/cadastro_produtos', $data);
                }
  
                function prepararAtualizacao($id){
                        $produtos = $this->Produtos_model->getById($id)->row();
                        
                        //Populando form com dados da Pessoa selecionada
                        $this->form_validation->id = $id;
                        $this->form_validation->nomeProduto = $produtos->nomeProduto;
                        $this->form_validation->preco = $produtos->preco;
                        $this->form_validation->estoque = $produtos->estoque;
                        
                        $data = array(
                               'title' => 'Editar',
                               'action' => site_url('produtos/atualizar'),
                );
                        
                $this->load->view('produtos/cadastro_produtos', $data);
                        
                }
                
        }
  
?>