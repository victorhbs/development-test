<!DOCTYPE html>
<html lang="pt-br">
<head>
        <title>Cadastro de Produtos</title>
        <meta name="description" content="Formulario de cadastro de produtos." />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        
</head>
<body>
        <form name="cadastroProdutos" id="cadastroProdutos" action="<?php echo $action; ?>" method="post">
                        <input type="hidden" name="id" class="text" value="<?php echo $this->form_validation->id; ?>"/>
                
                        <table style="font-family: tahoma; font-size: 12px;">
                                <tr>
                                        <td><label for="nomeProduto">Nome:</label></td>
                                        <td><input type="text" name="nomeProduto" size="30" maxlength="30" id="nomeProduto" value="<?php echo $this->form_validation->nomeProduto; ?>" /></td>
                                </tr>  
  
                                <tr>                           
                                        <td><label for="preco">Pre�o:</label></td>
                                        <td><input type="text" name="preco" size="60" maxlength="100" id="preco" value="<?php echo $this->form_validation->preco; ?>" /></td>
                                </tr>
                                
                                <tr>                           
                                        <td><label for="estoque">Qtd Estoque:</label></td>
                                        <td><input type="text" name="estoque" id="estoque" size="10" maxlength="14" value="<?php echo $this->form_validation->estoque; ?>" /></td>
                                </tr>
                               
                                <tr>   
                                        <td><input type="submit" id="botaoEnviar" value="Enviar" /></td>
                                        <td><input type="button" id="botaoCancelar" value="Cancelar" onclick="history.go(-1)" /></td>
                                </tr>
                                
                        </table>
        </form>
</body>
</html>