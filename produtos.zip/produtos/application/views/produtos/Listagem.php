<!DOCTYPE html>
<html lang="pt-br">
<head>
        <title>Listagem de Produtos</title>
        <meta name="description" content="Tela de Listagem de Produtoss." />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        
</head>
<body>
        <div>
                <table cellspacing="0" style="width: 70%;">
                <tr style="font-weight: bold;">
                        <td width="20%">Nome</td>
                        <td width="40%">Pre�o</td>
                        <td width="15%">Qtd Estoque</td>
                </tr>
                
                <?php
                        //Preenche a tabela com o array $produtos que vem do controller
                        foreach($produtos as $produtos){
                                echo "<tr>";
                                        echo "<td>" . anchor('produtos/prepararAtualizacao/'.$produtos->id, $produtos->nomeProduto) . "</td>";
                                        echo "<td>" . $produtos->preco . "</td>";
                                        echo "<td>" . $produtos->estoque . "</td>";
                                        echo "<td>" . anchor('$produtos/deletar/'.$produtos->id,'deletar',
                                        array('onclick'=>"return confirm('Tem certeza que deseja excluir?')")) . "</td>";
                                echo "</tr>";
                        }
                ?>
                
                </table>
                 
 
                
                <?php echo anchor('$produtos/prepararInsercao/','Novo', array('id' => 'novo')); ?>
        </div>
</body>
</html>