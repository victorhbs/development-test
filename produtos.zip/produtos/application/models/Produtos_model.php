<?php
        class Produtos_model extends CI_Model{
                
        //atributo que referencia o nome da tabela que desejamos acessar
                private $tabela = 'produtos';
                
                /* Construtor da classe
                 * Devemos sempre chamar o construtor da classe pai, no caso CI_Model
                 */
                function __construct(){
                        parent::__construct();
                }
  
                /* M�todo respons�vel por atualizar os dados de um produto
                 * Devemos atribuir o id do produto que queremos atualizar
                 * e o CI se responsabiliza por fazer a atualiza��o
                 */
                function atualizar($id, $produtos){
                        $this->db->where('id', $id);
                        $this->db->update($this->tabela, $produtos);
                }
                
                /* M�todo respons�vel por deletar um produto
                 * Assim como no m�todo atualizar, ele referencia o id
                 * e depois apaga o produto de acordo com seu id passado
                 */
                function deletar($id){
                        $this->db->where('id', $id);
                        $this->db->delete($this->tabela);
                }
                
                /* Adiciona uma novo produto � tabela
                 * Bem intuitivo, passamos a tabela e o objeto produto
                 * que estamos adicionando
                 */
                function inserir($produtos){
                        return $this->db->insert($this->tabela, $produtos);
                }
                
                /* M�todo que recupera a lista de todos os produtos
                 * cadastrados na tabela ordenando pelo atributo "nomeProduto"
                 *
                 */
                function getProdutos(){
                        $this->db->order_by('nomeProduto', 'asc');
                        return $this->db->get($this->tabela);
                }
                
                /* M�todo que recupera um produto espec�fico de
                 * acordo com seu id
                 */
                function getById($id){
                        $this->db->where('id', $id);
                        return  $this->db->get($this->tabela);
                }      
                
  
        }
?>